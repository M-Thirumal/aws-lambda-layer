def layer_fun():
    return "Hi, I am from layer_fun(), if you see me then your code is working!!!"